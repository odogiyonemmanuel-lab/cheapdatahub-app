import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Client-Info, Apikey",
};

const CDH_BASE = "https://www.cheapdatahub.ng/api/v1/resellers";
const PAYSTACK_BASE = "https://api.paystack.co";

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function isSuccess(data: any) {
  return data?.status === true || data?.status === "true" || data?.success === true;
}

async function getUser(req: Request, supabase: any) {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, "");
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) return null;
  return data.user;
}

async function requireAdmin(req: Request, supabase: any) {
  const user = await getUser(req, supabase);
  if (!user) return { user: null, error: jsonResponse({ error: "Unauthorized" }, 401) };
  const { data } = await supabase.rpc("is_admin", { p_user_id: user.id });
  if (!data) return { user: null, error: jsonResponse({ error: "Admin access required" }, 403) };
  return { user, error: null };
}

async function cdhRequest(path: string, apiKey: string, init?: RequestInit) {
  return fetch(`${CDH_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
  });
}

async function paystackRequest(path: string, secret: string, init?: RequestInit) {
  return fetch(`${PAYSTACK_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${secret}`,
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const url = new URL(req.url);
    const path = url.pathname.replace(/^\/functions\/v1\/vtu-proxy\/?/, "");
    const body = req.method === "POST"
      ? await req.json().catch(() => ({}))
      : {};

    // ------------------------------------------------------------
    // PUBLIC DATA PRICING
    // ------------------------------------------------------------
    // This route intentionally does not require a logged-in customer.
    // It is used by the public landing page to display current selling
    // prices and attract customers. It never exposes provider cost.
    if (path === "pricing/data-public" && req.method === "GET") {
      const { data, error } = await supabase
        .from("product_pricing")
        .select("bundle_id, network, plan_name, selling_price, active")
        .eq("active", true)
        .order("network")
        .order("selling_price");

      if (error) return jsonResponse({ error: error.message }, 500);

      return jsonResponse({
        products: (data ?? []).map((product) => ({
          bundle_id: product.bundle_id,
          network: product.network,
          plan_name: product.plan_name,
          selling_price: Number(product.selling_price),
          active: product.active,
        })),
      });
    }

    // Customer authentication for all normal routes.
    const user = await getUser(req, supabase);
    if (!user) return jsonResponse({ error: "Unauthorized" }, 401);

    const apiKey = Deno.env.get("CDH_API_KEY");
    if (!apiKey) {
      return jsonResponse({ error: "CDH_API_KEY is not configured" }, 500);
    }

    // ------------------------------------------------------------
    // CUSTOMER WALLET
    // ------------------------------------------------------------
    if (path === "wallet/balance") {
      const { data, error } = await supabase
        .from("wallets")
        .select("balance, updated_at")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) return jsonResponse({ error: error.message }, 500);

      return jsonResponse({
        balance: Number(data?.balance ?? 0),
        updated_at: data?.updated_at ?? null,
      });
    }

    // ------------------------------------------------------------
    // DATA PRICING
    // ------------------------------------------------------------
    if (path === "pricing/data") {
      const { data, error } = await supabase
        .from("product_pricing")
        .select("bundle_id, network, plan_name, provider_cost, selling_price, active")
        .eq("active", true)
        .order("network")
        .order("selling_price");

      if (error) return jsonResponse({ error: error.message }, 500);
      return jsonResponse({ products: data ?? [] });
    }

    // ------------------------------------------------------------
    // AIRTIME PRICING
    // ------------------------------------------------------------
    if (path === "pricing/airtime") {
      const { data, error } = await supabase
        .from("airtime_pricing")
        .select("markup_type, markup_value, active")
        .eq("id", 1)
        .maybeSingle();

      if (error) return jsonResponse({ error: error.message }, 500);
      return jsonResponse({
        markup_type: data?.markup_type ?? "fixed",
        markup_value: Number(data?.markup_value ?? 0),
        active: data?.active ?? true,
      });
    }

    // ------------------------------------------------------------
    // INITIALIZE PAYSTACK DEPOSIT
    // ------------------------------------------------------------
    if (path === "payments/initialize") {
      const secret = Deno.env.get("PAYSTACK_SECRET_KEY");
      if (!secret) return jsonResponse({ error: "PAYSTACK_SECRET_KEY is not configured" }, 500);

      const amount = Number(body.amount);
      if (!Number.isFinite(amount) || amount < 100) {
        return jsonResponse({ error: "Minimum wallet funding amount is ₦100" }, 422);
      }

      const reference = `SWIFT-${crypto.randomUUID()}`;
      const callbackUrl = `${url.origin}/?payment=success`;

      const { error: insertError } = await supabase.from("deposits").insert({
        user_id: user.id,
        reference,
        amount,
        currency: "NGN",
        status: "pending",
        gateway: "paystack",
      });

      if (insertError) return jsonResponse({ error: insertError.message }, 500);

      const response = await paystackRequest("/transaction/initialize", secret, {
        method: "POST",
        body: JSON.stringify({
          email: user.email,
          amount: Math.round(amount * 100),
          currency: "NGN",
          reference,
          callback_url: callbackUrl,
          metadata: {
            user_id: user.id,
            wallet_reference: reference,
          },
        }),
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok || !data.status || !data.data?.authorization_url) {
        await supabase
          .from("deposits")
          .update({ status: "failed", gateway_response: data })
          .eq("reference", reference);

        return jsonResponse(
          { error: data.message || "Unable to initialize payment" },
          response.status || 502
        );
      }

      return jsonResponse({
        reference,
        authorization_url: data.data.authorization_url,
      });
    }

    // ------------------------------------------------------------
    // VERIFY PAYSTACK DEPOSIT
    // ------------------------------------------------------------
    if (path === "payments/verify") {
      const secret = Deno.env.get("PAYSTACK_SECRET_KEY");
      if (!secret) return jsonResponse({ error: "PAYSTACK_SECRET_KEY is not configured" }, 500);

      const reference = String(body.reference || "");
      if (!reference) return jsonResponse({ error: "Payment reference is required" }, 422);

      const { data: deposit, error: depositError } = await supabase
        .from("deposits")
        .select("*")
        .eq("reference", reference)
        .eq("user_id", user.id)
        .maybeSingle();

      if (depositError || !deposit) {
        return jsonResponse({ error: "Payment record not found" }, 404);
      }

      if (deposit.status === "success") {
        const { data: wallet } = await supabase
          .from("wallets")
          .select("balance")
          .eq("user_id", user.id)
          .maybeSingle();

        return jsonResponse({
          success: true,
          already_credited: true,
          balance: Number(wallet?.balance ?? 0),
        });
      }

      const response = await paystackRequest(
        `/transaction/verify/${encodeURIComponent(reference)}`,
        secret
      );
      const data = await response.json().catch(() => ({}));

      const paidAmount = Number(data.data?.amount ?? 0) / 100;
      const expectedAmount = Number(deposit.amount);

      if (
        !response.ok ||
        data.data?.status !== "success" ||
        Math.abs(paidAmount - expectedAmount) > 0.001 ||
        data.data?.currency !== "NGN"
      ) {
        await supabase
          .from("deposits")
          .update({ status: "failed", gateway_response: data })
          .eq("reference", reference)
          .eq("status", "pending");

        return jsonResponse(
          { error: data.message || "Payment could not be verified" },
          400
        );
      }

      const { data: claimed } = await supabase
        .from("deposits")
        .update({
          status: "success",
          paid_at: new Date().toISOString(),
          gateway_response: data,
        })
        .eq("reference", reference)
        .eq("status", "pending")
        .select("id")
        .maybeSingle();

      if (claimed) {
        const { error: walletError } = await supabase.rpc("change_wallet_balance", {
          p_user_id: user.id,
          p_delta: expectedAmount,
          p_entry_type: "deposit",
          p_reference: reference,
          p_description: "Wallet funding via Paystack",
          p_metadata: { gateway: "paystack", paystack_reference: reference },
        });

        if (walletError) {
          return jsonResponse({ error: walletError.message }, 500);
        }
      }

      const { data: wallet } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", user.id)
        .maybeSingle();

      return jsonResponse({
        success: true,
        balance: Number(wallet?.balance ?? 0),
      });
    }

    // ------------------------------------------------------------
    // AIRTIME PURCHASE
    // ------------------------------------------------------------
    if (path === "airtime/purchase") {
      const providerAmount = Number(body.amount);
      const phoneNumber = String(body.phone_number || "");
      const network = String(body.network || "UNKNOWN");
      const providerId = Number(body.provider_id);

      if (!providerId || !phoneNumber || !Number.isFinite(providerAmount) || providerAmount < 100) {
        return jsonResponse({ error: "Invalid airtime purchase details" }, 422);
      }

      const { data: pricing } = await supabase
        .from("airtime_pricing")
        .select("markup_type, markup_value, active")
        .eq("id", 1)
        .maybeSingle();

      if (pricing && pricing.active === false) {
        return jsonResponse({ error: "Airtime sales are currently disabled" }, 503);
      }

      const markupType = pricing?.markup_type ?? "fixed";
      const markupValue = Number(pricing?.markup_value ?? 0);
      const customerAmount =
        markupType === "percent"
          ? providerAmount + (providerAmount * markupValue / 100)
          : providerAmount + markupValue;

      const reference = `AIR-${crypto.randomUUID()}`;

      const { data: wallet } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", user.id)
        .maybeSingle();

      if (Number(wallet?.balance ?? 0) < customerAmount) {
        return jsonResponse({ error: "Insufficient wallet balance" }, 402);
      }

      await supabase.from("transactions").insert({
        user_id: user.id,
        type: "airtime",
        network,
        phone_number: phoneNumber,
        amount: customerAmount,
        customer_amount: customerAmount,
        provider_cost: providerAmount,
        profit: customerAmount - providerAmount,
        provider_ref: reference,
        status: "pending",
        message: "Airtime purchase processing",
        metadata: { wallet_reference: reference },
      });

      const { error: debitError } = await supabase.rpc("change_wallet_balance", {
        p_user_id: user.id,
        p_delta: -customerAmount,
        p_entry_type: "purchase",
        p_reference: reference,
        p_description: `Airtime purchase for ${phoneNumber}`,
        p_metadata: { type: "airtime", network, phone_number: phoneNumber },
      });

      if (debitError) {
        if (debitError.message.includes("INSUFFICIENT_FUNDS")) {
          return jsonResponse({ error: "Insufficient wallet balance" }, 402);
        }
        return jsonResponse({ error: debitError.message }, 500);
      }

      try {
        const resp = await cdhRequest("/airtime/purchase/", apiKey, {
          method: "POST",
          body: JSON.stringify({
            provider_id: providerId,
            phone_number: phoneNumber,
            amount: providerAmount,
          }),
        });

        const data = await resp.json().catch(() => ({}));
        const success = isSuccess(data);

        if (success) {
          await supabase
            .from("transactions")
            .update({
              status: "success",
              provider_ref: data.reference || data.transaction_id?.toString() || reference,
              message: data.message || "Airtime purchase successful",
            })
            .eq("provider_ref", reference)
            .eq("user_id", user.id);

          return jsonResponse({
            ...data,
            charged: customerAmount,
            provider_cost: providerAmount,
            profit: customerAmount - providerAmount,
          }, 200);
        }

        await supabase.rpc("change_wallet_balance", {
          p_user_id: user.id,
          p_delta: customerAmount,
          p_entry_type: "refund",
          p_reference: `REFUND-${reference}`,
          p_description: "Automatic refund for failed airtime purchase",
          p_metadata: { original_reference: reference },
        });

        await supabase
          .from("transactions")
          .update({
            status: "failed",
            message: data.message || "Airtime purchase failed",
          })
          .eq("provider_ref", reference)
          .eq("user_id", user.id);

        return jsonResponse(
          { error: data.message || "Airtime purchase failed" },
          resp.ok ? 400 : resp.status
        );
      } catch (providerError) {
        await supabase.rpc("change_wallet_balance", {
          p_user_id: user.id,
          p_delta: customerAmount,
          p_entry_type: "refund",
          p_reference: `REFUND-${reference}`,
          p_description: "Automatic refund after provider error",
          p_metadata: { original_reference: reference },
        });

        await supabase
          .from("transactions")
          .update({
            status: "failed",
            message: "Provider request failed",
          })
          .eq("provider_ref", reference)
          .eq("user_id", user.id);

        return jsonResponse({ error: "Airtime provider request failed" }, 502);
      }
    }

    // ------------------------------------------------------------
    // DATA PURCHASE
    // ------------------------------------------------------------
    if (path === "data/purchase") {
      const bundleId = Number(body.bundle_id);
      const phoneNumber = String(body.phone_number || "");

      if (!bundleId || !phoneNumber) {
        return jsonResponse({ error: "Invalid data purchase details" }, 422);
      }

      const { data: product } = await supabase
        .from("product_pricing")
        .select("*")
        .eq("bundle_id", bundleId)
        .eq("active", true)
        .maybeSingle();

      if (!product) {
        return jsonResponse({ error: "This data plan is unavailable" }, 404);
      }

      const customerAmount = Number(product.selling_price);
      const providerCost = Number(product.provider_cost);
      const profit = customerAmount - providerCost;
      const reference = `DATA-${crypto.randomUUID()}`;

      const { data: wallet } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", user.id)
        .maybeSingle();

      if (Number(wallet?.balance ?? 0) < customerAmount) {
        return jsonResponse({ error: "Insufficient wallet balance" }, 402);
      }

      await supabase.from("transactions").insert({
        user_id: user.id,
        type: "data",
        network: product.network,
        phone_number: phoneNumber,
        amount: customerAmount,
        customer_amount: customerAmount,
        provider_cost: providerCost,
        profit,
        plan_name: product.plan_name,
        provider_ref: reference,
        status: "pending",
        message: "Data purchase processing",
        metadata: { bundle_id: bundleId, wallet_reference: reference },
      });

      const { error: debitError } = await supabase.rpc("change_wallet_balance", {
        p_user_id: user.id,
        p_delta: -customerAmount,
        p_entry_type: "purchase",
        p_reference: reference,
        p_description: `Data purchase: ${product.plan_name}`,
        p_metadata: { type: "data", bundle_id: bundleId, phone_number: phoneNumber },
      });

      if (debitError) {
        if (debitError.message.includes("INSUFFICIENT_FUNDS")) {
          return jsonResponse({ error: "Insufficient wallet balance" }, 402);
        }
        return jsonResponse({ error: debitError.message }, 500);
      }

      try {
        const resp = await cdhRequest("/data/purchase/", apiKey, {
          method: "POST",
          body: JSON.stringify({
            bundle_id: bundleId,
            phone_number: phoneNumber,
          }),
        });

        const data = await resp.json().catch(() => ({}));
        const success = isSuccess(data);

        if (success) {
          await supabase
            .from("transactions")
            .update({
              status: "success",
              provider_ref: data.reference || data.transaction_id?.toString() || reference,
              message: data.message || "Data purchase successful",
            })
            .eq("provider_ref", reference)
            .eq("user_id", user.id);

          return jsonResponse({
            ...data,
            charged: customerAmount,
            provider_cost: providerCost,
            profit,
          }, 200);
        }

        await supabase.rpc("change_wallet_balance", {
          p_user_id: user.id,
          p_delta: customerAmount,
          p_entry_type: "refund",
          p_reference: `REFUND-${reference}`,
          p_description: "Automatic refund for failed data purchase",
          p_metadata: { original_reference: reference },
        });

        await supabase
          .from("transactions")
          .update({
            status: "failed",
            message: data.message || "Data purchase failed",
          })
          .eq("provider_ref", reference)
          .eq("user_id", user.id);

        return jsonResponse(
          { error: data.message || "Data purchase failed" },
          resp.ok ? 400 : resp.status
        );
      } catch {
        await supabase.rpc("change_wallet_balance", {
          p_user_id: user.id,
          p_delta: customerAmount,
          p_entry_type: "refund",
          p_reference: `REFUND-${reference}`,
          p_description: "Automatic refund after provider error",
          p_metadata: { original_reference: reference },
        });

        await supabase
          .from("transactions")
          .update({
            status: "failed",
            message: "Provider request failed",
          })
          .eq("provider_ref", reference)
          .eq("user_id", user.id);

        return jsonResponse({ error: "Data provider request failed" }, 502);
      }
    }

    // ------------------------------------------------------------
    // CUSTOMER TRANSACTIONS
    // ------------------------------------------------------------
    if (path === "transactions") {
      const { data, error } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(100);

      if (error) return jsonResponse({ error: error.message }, 500);
      return jsonResponse({ transactions: data ?? [] });
    }

    // ------------------------------------------------------------
    // ADMIN DASHBOARD
    // ------------------------------------------------------------
    if (path === "admin/summary") {
      const check = await requireAdmin(req, supabase);
      if (check.error) return check.error;

      const [users, wallets, txns, deposits, ledger] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("wallets").select("balance"),
        supabase.from("transactions").select("amount, provider_cost, profit, status"),
        supabase.from("deposits").select("amount, status"),
        supabase.from("wallet_ledger").select("amount, entry_type"),
      ]);

      const totalCustomers = users.count ?? 0;
      const walletLiability = (wallets.data ?? []).reduce((s: number, x: any) => s + Number(x.balance || 0), 0);
      const successfulTxns = (txns.data ?? []).filter((x: any) => x.status === "success");
      const sales = successfulTxns.reduce((s: number, x: any) => s + Number(x.amount || 0), 0);
      const profit = successfulTxns.reduce((s: number, x: any) => s + Number(x.profit || 0), 0);
      const depositsTotal = (deposits.data ?? [])
        .filter((x: any) => x.status === "success")
        .reduce((s: number, x: any) => s + Number(x.amount || 0), 0);

      return jsonResponse({
        total_customers: totalCustomers,
        wallet_liability: walletLiability,
        successful_sales: sales,
        total_profit: profit,
        successful_deposits: depositsTotal,
        transactions: txns.data ?? [],
        deposits: deposits.data ?? [],
        ledger: ledger.data ?? [],
      });
    }

    // ------------------------------------------------------------
    // ADMIN CUSTOMERS
    // ------------------------------------------------------------
    if (path === "admin/customers") {
      const check = await requireAdmin(req, supabase);
      if (check.error) return check.error;

      const { data, error } = await supabase
        .from("profiles")
        .select("id, email, full_name, phone, role, created_at")
        .order("created_at", { ascending: false });

      if (error) return jsonResponse({ error: error.message }, 500);

      const ids = (data ?? []).map((x: any) => x.id);
      const { data: wallets } = await supabase
        .from("wallets")
        .select("user_id, balance")
        .in("user_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);

      const walletMap = new Map((wallets ?? []).map((w: any) => [w.user_id, Number(w.balance)]));
      return jsonResponse({
        customers: (data ?? []).map((x: any) => ({
          ...x,
          balance: walletMap.get(x.id) ?? 0,
        })),
      });
    }

    // ------------------------------------------------------------
    // ADMIN WALLET ADJUSTMENT
    // ------------------------------------------------------------
    if (path === "admin/wallet-adjust") {
      const check = await requireAdmin(req, supabase);
      if (check.error) return check.error;

      const targetUserId = String(body.user_id || "");
      const amount = Number(body.amount);
      const type = body.type === "debit" ? "admin_debit" : "admin_credit";
      const description = String(body.description || "Admin wallet adjustment");

      if (!targetUserId || !Number.isFinite(amount) || amount <= 0) {
        return jsonResponse({ error: "Invalid wallet adjustment" }, 422);
      }

      const delta = type === "admin_debit" ? -amount : amount;
      const reference = `ADMIN-${crypto.randomUUID()}`;

      const { error } = await supabase.rpc("change_wallet_balance", {
        p_user_id: targetUserId,
        p_delta: delta,
        p_entry_type: type,
        p_reference: reference,
        p_description: description,
        p_metadata: { admin_user_id: check.user!.id },
      });

      if (error) {
        if (error.message.includes("INSUFFICIENT_FUNDS")) {
          return jsonResponse({ error: "Customer wallet cannot go below zero" }, 400);
        }
        return jsonResponse({ error: error.message }, 500);
      }

      await supabase.from("admin_audit_logs").insert({
        admin_user_id: check.user!.id,
        action: type,
        target_user_id: targetUserId,
        amount,
        reference,
        details: { description },
      });

      return jsonResponse({ success: true, reference });
    }

    // ------------------------------------------------------------
    // ADMIN DATA PRICING UPDATE
    // ------------------------------------------------------------
    if (path === "admin/data-pricing") {
      const check = await requireAdmin(req, supabase);
      if (check.error) return check.error;

      const bundleId = Number(body.bundle_id);
      const providerCost = Number(body.provider_cost);
      const sellingPrice = Number(body.selling_price);
      const active = body.active !== false;

      if (!bundleId || !Number.isFinite(providerCost) || !Number.isFinite(sellingPrice) || providerCost < 0 || sellingPrice < 0) {
        return jsonResponse({ error: "Invalid product pricing" }, 422);
      }

      const { error } = await supabase
        .from("product_pricing")
        .update({
          provider_cost: providerCost,
          selling_price: sellingPrice,
          active,
          updated_at: new Date().toISOString(),
        })
        .eq("bundle_id", bundleId);

      if (error) return jsonResponse({ error: error.message }, 500);

      return jsonResponse({ success: true });
    }

    // ------------------------------------------------------------
    // ADMIN AIRTIME PRICING UPDATE
    // ------------------------------------------------------------
    if (path === "admin/airtime-pricing") {
      const check = await requireAdmin(req, supabase);
      if (check.error) return check.error;

      const markupType = body.markup_type === "percent" ? "percent" : "fixed";
      const markupValue = Number(body.markup_value);

      if (!Number.isFinite(markupValue) || markupValue < 0) {
        return jsonResponse({ error: "Invalid airtime markup" }, 422);
      }

      const { error } = await supabase
        .from("airtime_pricing")
        .update({
          markup_type: markupType,
          markup_value: markupValue,
          active: body.active !== false,
          updated_at: new Date().toISOString(),
        })
        .eq("id", 1);

      if (error) return jsonResponse({ error: error.message }, 500);
      return jsonResponse({ success: true });
    }

    // ------------------------------------------------------------
    // ADMIN PRICING LIST
    // ------------------------------------------------------------
    if (path === "admin/pricing") {
      const check = await requireAdmin(req, supabase);
      if (check.error) return check.error;

      const [{ data: products }, { data: airtime }] = await Promise.all([
        supabase.from("product_pricing").select("*").order("network").order("selling_price"),
        supabase.from("airtime_pricing").select("*").eq("id", 1).maybeSingle(),
      ]);

      return jsonResponse({
        products: products ?? [],
        airtime: airtime ?? null,
      });
    }

    return jsonResponse({ error: "Not found", path }, 404);
  } catch (err) {
    console.error("VTU proxy error:", err);
    return jsonResponse(
      { error: err instanceof Error ? err.message : "Internal server error" },
      500
    );
  }
});
