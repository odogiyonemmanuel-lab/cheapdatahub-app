import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

async function hmacSha512Hex(secret: string, body: string) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-512" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(body)
  );
  return Array.from(new Uint8Array(signature))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }

  try {
    const secret = Deno.env.get("PAYSTACK_SECRET_KEY");
    if (!secret) return jsonResponse({ error: "PAYSTACK_SECRET_KEY is not configured" }, 500);

    const rawBody = await req.text();
    const signature = req.headers.get("x-paystack-signature") || "";
    const expected = await hmacSha512Hex(secret, rawBody);

    if (!signature || signature.toLowerCase() !== expected.toLowerCase()) {
      return jsonResponse({ error: "Invalid signature" }, 401);
    }

    const event = JSON.parse(rawBody);

    // We only credit wallets for successful Paystack charges.
    if (event.event !== "charge.success") {
      return jsonResponse({ received: true });
    }

    const reference = String(
      event.data?.reference ||
      event.data?.metadata?.wallet_reference ||
      ""
    );
    const userId = String(event.data?.metadata?.user_id || "");
    const amount = Number(event.data?.amount || 0) / 100;
    const currency = event.data?.currency;

    if (!reference || !userId || !amount || currency !== "NGN") {
      return jsonResponse({ error: "Invalid payment payload" }, 400);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Find the payment created by our initialize endpoint.
    const { data: deposit } = await supabase
      .from("deposits")
      .select("*")
      .eq("reference", reference)
      .eq("user_id", userId)
      .maybeSingle();

    if (!deposit) {
      return jsonResponse({ error: "Deposit not found" }, 404);
    }

    if (Number(deposit.amount) !== amount) {
      return jsonResponse({ error: "Payment amount mismatch" }, 400);
    }

    // Idempotency: only the request that changes pending -> success
    // is allowed to credit the wallet.
    const { data: claimed } = await supabase
      .from("deposits")
      .update({
        status: "success",
        paid_at: new Date().toISOString(),
        gateway_response: event.data,
      })
      .eq("reference", reference)
      .eq("user_id", userId)
      .eq("status", "pending")
      .select("id")
      .maybeSingle();

    if (!claimed) {
      return jsonResponse({ received: true, already_processed: true });
    }

    const { error: walletError } = await supabase.rpc("change_wallet_balance", {
      p_user_id: userId,
      p_delta: amount,
      p_entry_type: "deposit",
      p_reference: reference,
      p_description: "Wallet funding via Paystack webhook",
      p_metadata: {
        gateway: "paystack",
        paystack_reference: reference,
        event: "charge.success",
      },
    });

    if (walletError) {
      // Do not silently lose a payment. The deposit is marked success,
      // so it can be reconciled from the admin dashboard if this fails.
      console.error("Wallet credit failed:", walletError);
      return jsonResponse({ error: "Wallet credit failed" }, 500);
    }

    return jsonResponse({ received: true });
  } catch (err) {
    console.error("Paystack webhook error:", err);
    return jsonResponse({ error: "Webhook processing failed" }, 500);
  }
});
