/*
  Server-only secret storage.

  The actual CheapDataHub API key MUST NOT be stored in source control.
  Set CDH_API_KEY in Supabase Edge Function Secrets instead.
*/

CREATE TABLE IF NOT EXISTS api_secrets (
  key_name text PRIMARY KEY,
  key_value text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE api_secrets ENABLE ROW LEVEL SECURITY;

-- No anon/authenticated policies. Prefer Edge Function Secrets for production.
