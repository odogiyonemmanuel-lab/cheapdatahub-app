/*
  CheapDataHub commerce layer
  - customer wallets + immutable ledger
  - Paystack deposits
  - admin role + audit trail
  - product pricing / profit controls
*/

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'customer'
  CHECK (role IN ('customer','admin'));

-- Prevent customers from changing their own role through the existing profile update policy.
DROP POLICY IF EXISTS "update_own_profile" ON public.profiles;
CREATE POLICY "update_own_profile" ON public.profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (
    auth.uid() = id
    AND role = 'customer'
  );

-- Admin helper. SECURITY DEFINER avoids RLS recursion.
CREATE OR REPLACE FUNCTION public.is_admin(p_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = p_user_id AND role = 'admin'
  );
$$;

REVOKE ALL ON FUNCTION public.is_admin(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_admin(uuid) TO authenticated, service_role;





-- Purchase transactions are now written by the Edge Function using service_role.
-- Remove the old direct frontend INSERT path.
DROP POLICY IF EXISTS "insert_own_transactions" ON public.transactions;

-- Wallet balances are server-controlled. Remove the old frontend UPDATE policy
-- from the starter schema so customers cannot change their own balance.
DROP POLICY IF EXISTS "update_own_wallet" ON public.wallets;

-- Customer wallet ledger
CREATE TABLE IF NOT EXISTS public.wallet_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  entry_type text NOT NULL CHECK (
    entry_type IN ('deposit','purchase','refund','admin_credit','admin_debit')
  ),
  amount numeric(14,2) NOT NULL,
  balance_after numeric(14,2) NOT NULL,
  reference text NOT NULL,
  description text NOT NULL DEFAULT '',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wallet_ledger_user_created
  ON public.wallet_ledger(user_id, created_at DESC);

ALTER TABLE public.wallet_ledger ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_wallet_ledger" ON public.wallet_ledger;
CREATE POLICY "select_own_wallet_ledger" ON public.wallet_ledger
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "admin_select_wallet_ledger" ON public.wallet_ledger;
CREATE POLICY "admin_select_wallet_ledger" ON public.wallet_ledger
  FOR SELECT TO authenticated
  USING (public.is_admin(auth.uid()));

-- Deposits / payment records
CREATE TABLE IF NOT EXISTS public.deposits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reference text NOT NULL UNIQUE,
  amount numeric(14,2) NOT NULL,
  currency text NOT NULL DEFAULT 'NGN',
  status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','success','failed')),
  gateway text NOT NULL DEFAULT 'paystack',
  gateway_response jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  paid_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_deposits_user_created
  ON public.deposits(user_id, created_at DESC);

ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_deposits" ON public.deposits;
CREATE POLICY "select_own_deposits" ON public.deposits
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "admin_select_deposits" ON public.deposits;
CREATE POLICY "admin_select_deposits" ON public.deposits
  FOR SELECT TO authenticated
  USING (public.is_admin(auth.uid()));

-- Product pricing. provider_cost is the amount you record as your CDH cost.
CREATE TABLE IF NOT EXISTS public.product_pricing (
  bundle_id integer PRIMARY KEY,
  network text NOT NULL,
  plan_name text NOT NULL,
  provider_cost numeric(14,2) NOT NULL DEFAULT 0,
  selling_price numeric(14,2) NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.product_pricing ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_active_product_pricing" ON public.product_pricing;
CREATE POLICY "select_active_product_pricing" ON public.product_pricing
  FOR SELECT TO authenticated
  USING (active = true OR public.is_admin(auth.uid()));

DROP POLICY IF EXISTS "admin_manage_product_pricing" ON public.product_pricing;
CREATE POLICY "admin_manage_product_pricing" ON public.product_pricing
  FOR ALL TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

INSERT INTO public.product_pricing
  (bundle_id, network, plan_name, provider_cost, selling_price, active)
VALUES
  (70, 'AIRTEL', '1GB (Social Bundle) Gifting (3 Days)', 295, 295, true),
  (13, 'AIRTEL', '500MB Gifting (7 days)', 490, 490, true),
  (69, 'AIRTEL', '1.5GB Gifting (1 Day)', 500, 500, true),
  (66, 'AIRTEL', '1.5GB Gifting (2 Days)', 599, 599, true),
  (15, 'AIRTEL', '1GB Gifting (7 Days)', 800, 800, true),
  (17, 'AIRTEL', '2GB Gifting (30 Days)', 1490, 1490, true),
  (52, 'AIRTEL', '5GB Gifting (7 Days)', 1570, 1570, true),
  (18, 'AIRTEL', '3GB Gifting (30 Days)', 1960, 1960, true),
  (22, 'AIRTEL', '6GB SME (7 Days)', 2455, 2455, true),
  (19, 'AIRTEL', '4GB Gifting (30 Days)', 2570, 2570, true),
  (20, 'AIRTEL', '8GB Gifting (30 Days)', 2999, 2999, true),
  (21, 'AIRTEL', '10GB Gifting (30 Days)', 4070, 4070, true),
  (42, 'GLO', '200MB Corporate Gifting (1 Day)', 92, 92, true),
  (35, 'GLO', '500MB Corporate Gifting (30 Days)', 225, 225, true),
  (68, 'GLO', '1GB Corporate Gifting (3 Days)', 300, 300, true),
  (36, 'GLO', '1GB Corporate Gifting (30 Days)', 425, 425, true),
  (41, 'GLO', '1GB Gifting (14 Days)', 485, 485, true),
  (40, 'GLO', '2GB Corporate Gifting (30 Days)', 850, 850, true),
  (37, 'GLO', '3GB Corporate Gifting (30 Days)', 1300, 1300, true),
  (54, 'GLO', '5GB Corporate Gifting (7 Days)', 1699, 1699, true),
  (38, 'GLO', '5GB Corporate Gifting (30 Days)', 2250, 2250, true),
  (39, 'GLO', '10GB Corporate Gifting (30 Days)', 4390, 4390, true),
  (59, 'GLO', '20.5GB Gifting (30 Days)', 5300, 5300, true),
  (58, 'GLO', '107GB Gifting (30 Days)', 19300, 19300, true),
  (43, 'MTN', '110MB Gifting (1 Day)', 99, 99, true),
  (74, 'MTN', '230MB Gifting (1 Day)', 200, 200, true),
  (76, 'MTN', '500MB SME (2 Days)', 250, 250, true),
  (78, 'MTN', '1GB SME (1 Day)', 270, 270, true),
  (81, 'MTN', '1GB Corporate Gifting (30 Days)', 280, 280, true),
  (44, 'MTN', '500MB SME (30 Days)', 300, 300, true),
  (77, 'MTN', '1GB SME (2 Days)', 399, 399, true),
  (45, 'MTN', '1GB SME (7 Days)', 450, 450, true),
  (46, 'MTN', '1GB SME (30 Days)', 570, 570, true),
  (79, 'MTN', '2.5GB SME (1 Day)', 600, 600, true),
  (27, 'MTN', '2.5GB Gifting (2 Days)', 900, 900, true),
  (71, 'MTN', '2GB Gifting (7 Days)', 900, 900, true),
  (47, 'MTN', '2GB SME (7 Days)', 930, 930, true),
  (60, 'MTN', '4.5GB Gifting (1 Day)', 1050, 1050, true),
  (48, 'MTN', '2GB SME (30 Days)', 1150, 1150, true),
  (61, 'MTN', '4GB Gifting (2 Days)', 1175, 1175, true),
  (80, 'MTN', '5GB Corporate Gifting (14 Days)', 1299, 1299, true),
  (82, 'MTN', '5GB SME (30 Days)', 1299, 1299, true),
  (49, 'MTN', '3GB SME (30 Days)', 1370, 1370, true),
  (50, 'MTN', '5GB SME (30 Days)', 2050, 2050, true),
  (53, 'MTN', '6GB Gifting (7 Days)', 2495, 2495, true),
  (33, 'MTN', '7GB Gifting (30 Days)', 3600, 3600, true),
  (55, 'MTN', '11GB Gifting (7 Days)', 3550, 3550, true),
  (67, 'MTN', '10GB Gifting (30 Days)', 4800, 4800, true),
  (57, 'MTN', '36GB Gifting (30 Days)', 10900, 10900, true),
  (51, 'MTN', '75GB SME (30 Days)', 17990, 17990, true)
ON CONFLICT (bundle_id) DO NOTHING;

-- Airtime markup settings.
CREATE TABLE IF NOT EXISTS public.airtime_pricing (
  id integer PRIMARY KEY CHECK (id = 1),
  markup_type text NOT NULL DEFAULT 'fixed'
    CHECK (markup_type IN ('fixed','percent')),
  markup_value numeric(14,2) NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.airtime_pricing ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_airtime_pricing" ON public.airtime_pricing;
CREATE POLICY "select_airtime_pricing" ON public.airtime_pricing
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "admin_manage_airtime_pricing" ON public.airtime_pricing;
CREATE POLICY "admin_manage_airtime_pricing" ON public.airtime_pricing
  FOR ALL TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

INSERT INTO public.airtime_pricing(id, markup_type, markup_value, active)
VALUES (1, 'fixed', 0, true)
ON CONFLICT (id) DO NOTHING;

-- Admin audit trail
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE RESTRICT,
  action text NOT NULL,
  target_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  amount numeric(14,2),
  reference text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_select_audit_logs" ON public.admin_audit_logs;
CREATE POLICY "admin_select_audit_logs" ON public.admin_audit_logs
  FOR SELECT TO authenticated
  USING (public.is_admin(auth.uid()));

-- Extend transactions for accounting.
ALTER TABLE public.transactions
  ADD COLUMN IF NOT EXISTS customer_amount numeric(14,2),
  ADD COLUMN IF NOT EXISTS provider_cost numeric(14,2),
  ADD COLUMN IF NOT EXISTS profit numeric(14,2),
  ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}'::jsonb;

UPDATE public.transactions
SET customer_amount = amount
WHERE customer_amount IS NULL;

-- Atomic wallet adjustment. Negative deltas are rejected if they would overdraw.
CREATE OR REPLACE FUNCTION public.change_wallet_balance(
  p_user_id uuid,
  p_delta numeric,
  p_entry_type text,
  p_reference text,
  p_description text,
  p_metadata jsonb DEFAULT '{}'::jsonb
)
RETURNS public.wallets
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  w public.wallets;
  new_balance numeric(14,2);
BEGIN
  SELECT * INTO w
  FROM public.wallets
  WHERE user_id = p_user_id
  FOR UPDATE;

  IF NOT FOUND THEN
    INSERT INTO public.wallets(user_id, balance)
    VALUES (p_user_id, 0)
    RETURNING * INTO w;
  END IF;

  new_balance := w.balance + p_delta;

  IF new_balance < 0 THEN
    RAISE EXCEPTION 'INSUFFICIENT_FUNDS';
  END IF;

  UPDATE public.wallets
  SET balance = new_balance, updated_at = now()
  WHERE id = w.id
  RETURNING * INTO w;

  INSERT INTO public.wallet_ledger(
    user_id, entry_type, amount, balance_after,
    reference, description, metadata
  )
  VALUES (
    p_user_id, p_entry_type, p_delta, new_balance,
    p_reference, p_description, COALESCE(p_metadata, '{}'::jsonb)
  );

  RETURN w;
END;
$$;

REVOKE ALL ON FUNCTION public.change_wallet_balance(
  uuid, numeric, text, text, text, jsonb
) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.change_wallet_balance(
  uuid, numeric, text, text, text, jsonb
) TO service_role;

-- Useful admin indexes.
CREATE INDEX IF NOT EXISTS idx_transactions_status
  ON public.transactions(status);
CREATE INDEX IF NOT EXISTS idx_transactions_created_at
  ON public.transactions(created_at DESC);
