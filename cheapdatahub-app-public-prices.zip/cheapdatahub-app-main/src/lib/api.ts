import { supabase } from "./supabase";
import type { Transaction } from "@/types";

const EDGE_FUNCTION = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/vtu-proxy`;

async function getHeaders() {
  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (!session?.access_token) {
    throw new Error("Please sign in again.");
  }

  return {
    Authorization: `Bearer ${session.access_token}`,
    "Content-Type": "application/json",
    apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
  };
}

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const headers = await getHeaders();

  const resp = await fetch(`${EDGE_FUNCTION}/${path}`, {
    ...options,
    headers: {
      ...headers,
      ...(options.headers || {}),
    },
  });

  const data = await resp.json().catch(() => ({}));

  if (!resp.ok) {
    throw new Error(
      data.error || data.message || `Request failed (${resp.status})`
    );
  }

  return data as T;
}

export async function getWalletBalance(): Promise<{ balance: number }> {
  return request("wallet/balance");
}

export async function getPublicDataPricing() {
  const baseUrl = import.meta.env.VITE_SUPABASE_URL;
  const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

  const resp = await fetch(
    `${baseUrl}/functions/v1/vtu-proxy/pricing/data-public`,
    {
      headers: {
        apikey: anonKey,
        "Content-Type": "application/json",
      },
    }
  );

  const data = await resp.json().catch(() => ({}));

  if (!resp.ok) {
    throw new Error(
      data.error || data.message || `Request failed (${resp.status})`
    );
  }

  return data as {
    products: Array<{
      bundle_id: number;
      network: string;
      plan_name: string;
      selling_price: number;
      active: boolean;
    }>;
  };
}

export async function getDataPricing() {
  return request<{
    products: Array<{
      bundle_id: number;
      network: string;
      plan_name: string;
      provider_cost: number;
      selling_price: number;
      active: boolean;
    }>;
  }>("pricing/data");
}

export async function getAirtimePricing() {
  return request<{
    markup_type: "fixed" | "percent";
    markup_value: number;
    active: boolean;
  }>("pricing/airtime");
}

export async function initializeWalletFunding(amount: number) {
  return request<{
    reference: string;
    authorization_url: string;
  }>("payments/initialize", {
    method: "POST",
    body: JSON.stringify({ amount }),
  });
}

export async function verifyWalletFunding(reference: string) {
  return request<{
    success: boolean;
    balance: number;
    already_credited?: boolean;
  }>("payments/verify", {
    method: "POST",
    body: JSON.stringify({ reference }),
  });
}

export async function purchaseAirtime(params: {
  provider_id: number;
  phone_number: string;
  amount: number;
  network: string;
}) {
  return request<{
    message: string;
    reference?: string;
    charged?: number;
    provider_cost?: number;
    profit?: number;
  }>("airtime/purchase", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

export async function purchaseData(params: {
  bundle_id: number;
  phone_number: string;
  plan_name: string;
  network: string;
  amount: number;
}) {
  return request<{
    message: string;
    reference?: string;
    charged?: number;
    provider_cost?: number;
    profit?: number;
  }>("data/purchase", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

export async function getTransactions(): Promise<Transaction[]> {
  const data = await request<{ transactions: Transaction[] }>("transactions");
  return data.transactions ?? [];
}

export async function getAdminSummary() {
  return request<{
    total_customers: number;
    wallet_liability: number;
    successful_sales: number;
    total_profit: number;
    successful_deposits: number;
  }>("admin/summary");
}

export async function getAdminCustomers() {
  return request<{
    customers: Array<{
      id: string;
      email: string;
      full_name: string;
      phone: string;
      role: string;
      created_at: string;
      balance: number;
    }>;
  }>("admin/customers");
}

export async function getAdminPricing() {
  return request<{
    products: Array<{
      bundle_id: number;
      network: string;
      plan_name: string;
      provider_cost: number;
      selling_price: number;
      active: boolean;
    }>;
    airtime: {
      markup_type: "fixed" | "percent";
      markup_value: number;
      active: boolean;
    } | null;
  }>("admin/pricing");
}

export async function adjustCustomerWallet(params: {
  user_id: string;
  amount: number;
  type: "credit" | "debit";
  description: string;
}) {
  return request("admin/wallet-adjust", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

export async function updateDataPricing(params: {
  bundle_id: number;
  provider_cost: number;
  selling_price: number;
  active: boolean;
}) {
  return request("admin/data-pricing", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

export async function updateAirtimePricing(params: {
  markup_type: "fixed" | "percent";
  markup_value: number;
  active: boolean;
}) {
  return request("admin/airtime-pricing", {
    method: "POST",
    body: JSON.stringify(params),
  });
}
