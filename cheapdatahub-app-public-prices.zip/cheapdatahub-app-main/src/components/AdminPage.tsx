import { useEffect, useState } from "react";
import {
  adjustCustomerWallet,
  getAdminCustomers,
  getAdminPricing,
  getAdminSummary,
  updateAirtimePricing,
  updateDataPricing,
} from "@/lib/api";
import { formatNaira } from "@/lib/dataPlans";
import {
  ShieldCheck,
  Loader2,
  RefreshCw,
  Users,
  Wallet,
  TrendingUp,
  Receipt,
  Save,
  Plus,
  Minus,
} from "lucide-react";

type Tab = "overview" | "customers" | "pricing";

type Customer = {
  id: string;
  email: string;
  full_name: string;
  phone: string;
  role: string;
  created_at: string;
  balance: number;
};

type Product = {
  bundle_id: number;
  network: string;
  plan_name: string;
  provider_cost: number;
  selling_price: number;
  active: boolean;
};

export default function AdminPage() {
  const [tab, setTab] = useState<Tab>("overview");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [summary, setSummary] = useState<any>(null);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [airtime, setAirtime] = useState<any>(null);

  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [adjustAmount, setAdjustAmount] = useState("");
  const [adjustType, setAdjustType] = useState<"credit" | "debit">("credit");
  const [adjustDescription, setAdjustDescription] = useState("");

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, c, p] = await Promise.all([
        getAdminSummary(),
        getAdminCustomers(),
        getAdminPricing(),
      ]);
      setSummary(s);
      setCustomers(c.customers);
      setProducts(p.products);
      setAirtime(p.airtime);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load admin data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const saveProduct = async (product: Product) => {
    setSaving(`product-${product.bundle_id}`);
    setError(null);
    setMessage(null);
    try {
      await updateDataPricing({
        bundle_id: product.bundle_id,
        provider_cost: Number(product.provider_cost),
        selling_price: Number(product.selling_price),
        active: product.active,
      });
      setMessage(`${product.plan_name} pricing saved.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save pricing");
    } finally {
      setSaving(null);
    }
  };

  const saveAirtime = async () => {
    if (!airtime) return;
    setSaving("airtime");
    setError(null);
    setMessage(null);
    try {
      await updateAirtimePricing({
        markup_type: airtime.markup_type,
        markup_value: Number(airtime.markup_value),
        active: airtime.active,
      });
      setMessage("Airtime pricing saved.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save airtime pricing");
    } finally {
      setSaving(null);
    }
  };

  const adjustWallet = async () => {
    const amount = Number(adjustAmount);
    if (!selectedCustomer || !Number.isFinite(amount) || amount <= 0) {
      setError("Select a customer and enter a valid amount.");
      return;
    }

    setSaving("wallet");
    setError(null);
    setMessage(null);
    try {
      await adjustCustomerWallet({
        user_id: selectedCustomer,
        amount,
        type: adjustType,
        description: adjustDescription || "Admin wallet adjustment",
      });
      setAdjustAmount("");
      setAdjustDescription("");
      setMessage("Wallet adjusted successfully.");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Wallet adjustment failed");
    } finally {
      setSaving(null);
    }
  };

  if (loading && !summary) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-7 h-7 text-emerald-400 animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            <h1 className="text-2xl font-bold">Admin</h1>
          </div>
          <p className="text-slate-400 text-sm mt-1">
            Control customer wallets, pricing and profit margins.
          </p>
        </div>

        <button
          onClick={load}
          className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg border border-slate-700 text-slate-300 hover:text-white"
        >
          <RefreshCw className="w-4 h-4" />
          Refresh
        </button>
      </div>

      {message && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl p-3 text-sm mb-5">
          {message}
        </div>
      )}

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-xl p-3 text-sm mb-5">
          {error}
        </div>
      )}

      <div className="flex gap-2 mb-6 overflow-x-auto">
        {([
          ["overview", "Overview"],
          ["customers", "Customers"],
          ["pricing", "Pricing"],
        ] as [Tab, string][]).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap ${
              tab === key
                ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                : "bg-slate-900 border border-slate-800 text-slate-400"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Stat icon={<Users />} label="Customers" value={summary?.total_customers ?? 0} />
          <Stat
            icon={<Wallet />}
            label="Customer Wallet Liability"
            value={formatNaira(summary?.wallet_liability ?? 0)}
          />
          <Stat
            icon={<Receipt />}
            label="Successful Sales"
            value={formatNaira(summary?.successful_sales ?? 0)}
          />
          <Stat
            icon={<TrendingUp />}
            label="Recorded Profit"
            value={formatNaira(summary?.total_profit ?? 0)}
          />
        </div>
      )}

      {tab === "customers" && (
        <div className="space-y-6">
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
            <h2 className="font-semibold mb-4">Manual Wallet Adjustment</h2>
            <p className="text-xs text-slate-500 mb-4">
              Use this only for legitimate support/reconciliation actions. Every adjustment is recorded in the admin audit log.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <select
                value={selectedCustomer}
                onChange={(e) => setSelectedCustomer(e.target.value)}
                className="bg-slate-950 text-white rounded-lg px-3 py-3 border border-slate-800"
              >
                <option value="">Select customer</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.email} — {formatNaira(c.balance)}
                  </option>
                ))}
              </select>

              <input
                type="number"
                min="1"
                value={adjustAmount}
                onChange={(e) => setAdjustAmount(e.target.value)}
                placeholder="Amount"
                className="bg-slate-950 text-white rounded-lg px-3 py-3 border border-slate-800"
              />

              <div className="flex gap-2">
                <button
                  onClick={() => setAdjustType("credit")}
                  className={`flex-1 py-3 rounded-lg border ${
                    adjustType === "credit"
                      ? "border-emerald-500 text-emerald-400 bg-emerald-500/10"
                      : "border-slate-800 text-slate-400"
                  }`}
                >
                  <Plus className="w-4 h-4 inline mr-1" />
                  Credit
                </button>
                <button
                  onClick={() => setAdjustType("debit")}
                  className={`flex-1 py-3 rounded-lg border ${
                    adjustType === "debit"
                      ? "border-red-500 text-red-400 bg-red-500/10"
                      : "border-slate-800 text-slate-400"
                  }`}
                >
                  <Minus className="w-4 h-4 inline mr-1" />
                  Debit
                </button>
              </div>

              <input
                value={adjustDescription}
                onChange={(e) => setAdjustDescription(e.target.value)}
                placeholder="Reason / description"
                className="bg-slate-950 text-white rounded-lg px-3 py-3 border border-slate-800"
              />
            </div>

            <button
              onClick={adjustWallet}
              disabled={saving === "wallet"}
              className="mt-3 bg-emerald-500 text-slate-950 font-semibold px-4 py-3 rounded-lg disabled:opacity-50"
            >
              {saving === "wallet" ? "Saving..." : "Apply Wallet Adjustment"}
            </button>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-5 border-b border-slate-800 font-semibold">
              Customers
            </div>
            <div className="divide-y divide-slate-800">
              {customers.map((customer) => (
                <div key={customer.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div className="font-medium">{customer.full_name || "Customer"}</div>
                    <div className="text-xs text-slate-500">{customer.email}</div>
                  </div>
                  <div className="font-semibold text-emerald-400">
                    {formatNaira(customer.balance)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === "pricing" && (
        <div className="space-y-6">
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between gap-4 mb-2">
              <h2 className="font-semibold">Airtime Margin</h2>
              <button
                onClick={saveAirtime}
                disabled={saving === "airtime"}
                className="bg-emerald-500 text-slate-950 font-semibold px-3 py-2 rounded-lg flex items-center gap-2 disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                Save
              </button>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Fixed ₦ markup adds that fee to every airtime purchase. Percentage markup uses the airtime face value.
            </p>

            {airtime && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <select
                  value={airtime.markup_type}
                  onChange={(e) =>
                    setAirtime({ ...airtime, markup_type: e.target.value })
                  }
                  className="bg-slate-950 text-white rounded-lg px-3 py-3 border border-slate-800"
                >
                  <option value="fixed">Fixed ₦</option>
                  <option value="percent">Percentage %</option>
                </select>
                <input
                  type="number"
                  min="0"
                  value={airtime.markup_value}
                  onChange={(e) =>
                    setAirtime({ ...airtime, markup_value: Number(e.target.value) })
                  }
                  className="bg-slate-950 text-white rounded-lg px-3 py-3 border border-slate-800"
                />
                <label className="flex items-center gap-2 text-sm text-slate-300">
                  <input
                    type="checkbox"
                    checked={airtime.active}
                    onChange={(e) =>
                      setAirtime({ ...airtime, active: e.target.checked })
                    }
                  />
                  Airtime sales enabled
                </label>
              </div>
            )}
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-5 border-b border-slate-800">
              <h2 className="font-semibold">Data Pricing</h2>
              <p className="text-xs text-slate-500 mt-1">
                Provider cost is your recorded CDH cost. Selling price is what the customer pays.
              </p>
            </div>

            <div className="divide-y divide-slate-800">
              {products.map((product) => (
                <div key={product.bundle_id} className="p-4">
                  <div className="flex flex-col lg:flex-row lg:items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm">{product.network} · {product.plan_name}</div>
                      <div className="text-xs text-slate-500">Bundle #{product.bundle_id}</div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 w-full lg:w-72">
                      <input
                        type="number"
                        min="0"
                        value={product.provider_cost}
                        onChange={(e) =>
                          setProducts((items) =>
                            items.map((p) =>
                              p.bundle_id === product.bundle_id
                                ? { ...p, provider_cost: Number(e.target.value) }
                                : p
                            )
                          )
                        }
                        placeholder="Provider cost"
                        className="bg-slate-950 text-white rounded-lg px-3 py-2 border border-slate-800 text-sm"
                      />
                      <input
                        type="number"
                        min="0"
                        value={product.selling_price}
                        onChange={(e) =>
                          setProducts((items) =>
                            items.map((p) =>
                              p.bundle_id === product.bundle_id
                                ? { ...p, selling_price: Number(e.target.value) }
                                : p
                            )
                          )
                        }
                        placeholder="Selling price"
                        className="bg-slate-950 text-white rounded-lg px-3 py-2 border border-slate-800 text-sm"
                      />
                    </div>

                    <div className={`text-sm font-semibold w-24 ${
                      product.selling_price - product.provider_cost >= 0
                        ? "text-emerald-400"
                        : "text-red-400"
                    }`}>
                      {formatNaira(product.selling_price - product.provider_cost)}
                    </div>

                    <label className="text-xs text-slate-400 flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={product.active}
                        onChange={(e) =>
                          setProducts((items) =>
                            items.map((p) =>
                              p.bundle_id === product.bundle_id
                                ? { ...p, active: e.target.checked }
                                : p
                            )
                          )
                        }
                      />
                      Active
                    </label>

                    <button
                      onClick={() => saveProduct(product)}
                      disabled={saving === `product-${product.bundle_id}`}
                      className="p-2 rounded-lg border border-slate-700 text-slate-300 hover:text-emerald-400 disabled:opacity-50"
                      title="Save"
                    >
                      {saving === `product-${product.bundle_id}` ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Save className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
      <div className="w-9 h-9 bg-emerald-500/10 text-emerald-400 rounded-lg flex items-center justify-center mb-3">
        {icon}
      </div>
      <div className="text-xs text-slate-500 uppercase tracking-wide">{label}</div>
      <div className="text-xl font-bold mt-1">{value}</div>
    </div>
  );
}
