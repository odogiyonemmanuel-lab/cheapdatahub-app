import { useState } from "react";
import { initializeWalletFunding } from "@/lib/api";
import { formatNaira } from "@/lib/dataPlans";
import { Loader2, WalletCards, ShieldCheck } from "lucide-react";

export default function FundWallet({ onSuccess }: { onSuccess: () => void }) {
  const [amount, setAmount] = useState<number | "">("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const presets = [500, 1000, 2000, 5000, 10000];

  const startPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const value = Number(amount);
    if (!Number.isFinite(value) || value < 100) {
      setError("Enter an amount of at least ₦100.");
      return;
    }

    setLoading(true);
    try {
      const result = await initializeWalletFunding(value);
      // Paystack hosts the payment page. No secret key is exposed to the browser.
      window.location.href = result.authorization_url;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to start payment.");
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold mb-1">Fund Wallet</h1>
      <p className="text-slate-400 text-sm mb-6">
        Add money to your SwiftVTU wallet securely.
      </p>

      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-11 h-11 bg-emerald-500/10 rounded-xl flex items-center justify-center">
            <WalletCards className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="font-semibold">Wallet funding</div>
            <div className="text-xs text-slate-500">
              Payments are verified before your wallet is credited.
            </div>
          </div>
        </div>

        <form onSubmit={startPayment} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Amount (NGN)
            </label>
            <input
              type="number"
              min={100}
              value={amount}
              onChange={(e) =>
                setAmount(e.target.value === "" ? "" : Number(e.target.value))
              }
              placeholder="Enter amount"
              className="w-full bg-slate-950 text-white rounded-xl px-4 py-3 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
            />

            <div className="flex flex-wrap gap-2 mt-3">
              {presets.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setAmount(preset)}
                  className="px-3 py-2 rounded-lg text-xs font-medium border border-slate-700 bg-slate-800/60 text-slate-300 hover:border-emerald-500 hover:text-emerald-400"
                >
                  {formatNaira(preset)}
                </button>
              ))}
            </div>
          </div>

          {amount && Number(amount) >= 100 && (
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
              <span className="text-slate-400 text-sm">You'll fund</span>
              <span className="font-bold text-emerald-400">
                {formatNaira(Number(amount))}
              </span>
            </div>
          )}

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-xl p-3 text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !amount}
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl py-3.5 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Opening secure payment...
              </>
            ) : (
              <>
                <WalletCards className="w-5 h-5" />
                Continue to Payment
              </>
            )}
          </button>
        </form>

        <div className="flex items-center gap-2 mt-5 text-xs text-slate-500">
          <ShieldCheck className="w-4 h-4" />
          Your payment is verified server-side before wallet credit.
        </div>
      </div>
    </div>
  );
}
