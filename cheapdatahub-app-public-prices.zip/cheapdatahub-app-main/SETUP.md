# CheapDataHub / SwiftVTU commerce setup

This build adds:

- Customer wallet balances controlled by Supabase Edge Functions
- Wallet ledger and automatic refunds
- Paystack wallet funding
- Paystack webhook verification
- Data selling-price controls
- Airtime markup controls
- Admin dashboard
- Admin wallet adjustments with audit log
- Sales / cost / profit reporting
- CDH provider requests kept server-side

## 1. Supabase database

Run these migrations in order:

1. `supabase/migrations/20260812113024_create_vtu_schema.sql`
2. `supabase/migrations/20260812113128_store_cdh_api_key.sql`
3. `supabase/migrations/20260822090000_commerce_admin.sql`

If the first two migrations were already applied to your project, only run the new commerce migration in the Supabase SQL Editor.

## 2. Supabase Edge Function secrets

In Supabase:

**Edge Functions → Secrets**

Set:

- `CDH_API_KEY` = your current regenerated CheapDataHub API key
- `PAYSTACK_SECRET_KEY` = your Paystack Secret Key

Never commit either secret to GitHub.

The old `api_secrets` migration no longer contains a key. The Edge Function reads `CDH_API_KEY` directly from Supabase Secrets.

## 3. Deploy Edge Functions

Deploy:

- `supabase/functions/vtu-proxy/index.ts`
- `supabase/functions/paystack-webhook/index.ts`

The resulting webhook URL will be:

`https://YOUR_PROJECT_REF.supabase.co/functions/v1/paystack-webhook`

Use that exact URL in your Paystack dashboard as the webhook URL.

## 4. Vercel environment variables

Keep:

- `VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co`
- `VITE_SUPABASE_ANON_KEY=your_supabase_anon_key`

No CDH or Paystack secret belongs in Vercel frontend variables.

Redeploy Vercel after changing VITE variables.

## 5. Create the first admin

After your own user has signed up, run this in Supabase SQL Editor:

```sql
update public.profiles
set role = 'admin'
where email = 'YOUR_ADMIN_EMAIL';
```

Replace the email with the email of the account you want to administer.

Do not make every customer an admin.

## 6. How customer funding works

Customer:

1. Opens Fund Wallet.
2. Enters an amount.
3. Supabase initializes a Paystack transaction.
4. Customer completes payment on Paystack.
5. Paystack redirects the customer back.
6. The app verifies the transaction.
7. Paystack's signed webhook also verifies the event.
8. The wallet is credited exactly once.

The payment record uses the Paystack reference as an idempotency key.

## 7. How purchases work

Airtime:

- Customer chooses face value.
- Admin controls fixed or percentage markup.
- Customer wallet is charged for the selling price.
- CDH receives only the airtime face value.
- If CDH fails, the wallet is automatically refunded.
- Profit is recorded.

Data:

- Admin controls provider cost and selling price for each bundle.
- Customer wallet is charged at the selling price.
- CDH receives the bundle ID and phone number.
- If CDH fails, the wallet is automatically refunded.
- Profit is recorded as selling price minus recorded provider cost.

## 8. Important accounting note

`provider_cost` for data is an admin-maintained accounting value. This build does not invent a CDH cost that the CDH API has not supplied.

The Admin → Pricing screen lets you enter the actual cost you are charged by your provider and your desired selling price.

Do not alter or falsify provider responses. Your profit comes from your own legitimate selling price/margin.

## 9. Security changes

The commerce migration removes:

- direct customer wallet UPDATE access
- direct customer transaction INSERT access

Wallet changes now go through the server-side wallet RPC and Edge Functions.

The CheapDataHub and Paystack secret keys are never sent to the browser.

## 10. Existing static data plans

The commerce migration seeds the existing 50 data bundles from `src/lib/dataPlans.ts`.

The customer Data screen then reads the selling prices from `product_pricing`, so changes made by the Admin page take effect without changing the frontend code.

## 11. Recommended first test

Use a small test amount and a Paystack test/live environment appropriate to your account.

Test in this order:

1. Sign up.
2. Confirm the customer wallet starts at ₦0.
3. Fund with a small amount.
4. Confirm the wallet increases once.
5. Set a small data selling price in Admin.
6. Make a data purchase.
7. Confirm wallet deduction.
8. Confirm the CDH transaction.
9. Test a failed provider transaction and confirm automatic refund.
10. Check Admin profit reporting.

Do not test with money you cannot afford to lose until payment verification and provider refund behaviour have been confirmed.
