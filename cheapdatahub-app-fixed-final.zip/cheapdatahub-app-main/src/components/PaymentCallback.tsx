import { useEffect, useState } from "react";
import { verifyWalletFunding } from "@/lib/api";

export default function PaymentCallback() {
  const [message, setMessage] = useState("Verifying your payment...");
  const [done, setDone] = useState(false);

  useEffect(() => {
    const run = async () => {
      const q = new URLSearchParams(window.location.search);
      const status = (q.get("status") || "").toLowerCase();
      const transactionId = q.get("transaction_id") || q.get("transactionId");
      const txRef = q.get("tx_ref") || q.get("txRef");

      if (status && status !== "successful") {
        setMessage("Payment was not successful. Your wallet was not charged by this app.");
        setDone(true);
        return;
      }
      if (!transactionId || !txRef) {
        setMessage("Missing payment verification details.");
        setDone(true);
        return;
      }

      try {
        const result = await verifyWalletFunding({ transactionId, txRef });
        setMessage(result.message || "Payment verified. Your wallet has been updated.");
      } catch (error) {
        setMessage(error instanceof Error ? error.message : "Unable to verify payment.");
      } finally {
        setDone(true);
      }
    };
    void run();
  }, []);

  return (
    <main className="min-h-screen bg-slate-950 flex items-center justify-center p-6 text-white">
      <section className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 text-center">
        <h1 className="text-xl font-bold">CheapDataHub Payment</h1>
        <p className="mt-4 text-slate-300">{message}</p>
        {done && (
          <button onClick={() => window.location.assign("/")}
            className="mt-6 rounded-xl bg-emerald-500 px-5 py-3 font-semibold text-slate-950">
            Return to Dashboard
          </button>
        )}
      </section>
    </main>
  );
}
